import React, { useEffect, useState, useMemo } from "react";

const WHATSAPP_NUMBER = "573022684340"; // Tu número de WhatsApp
const SHEET_URL = "https://docs.google.com/spreadsheets/d/e/ENLACE_DE_EJEMPLO/pub?output=csv"; // Reemplázalo con tu Google Sheet en CSV

function formatCOP(value) {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    maximumFractionDigits: 0,
  }).format(value);
}

export default function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState({});

  useEffect(() => {
    async function fetchProducts() {
      try {
        const res = await fetch(SHEET_URL);
        const text = await res.text();
        const rows = text.split("\n").map((r) => r.split(","));
        const headers = rows[0].map((h) => h.trim().toLowerCase());
        const data = rows.slice(1).map((cols) => {
          const obj = {};
          headers.forEach((h, i) => (obj[h] = cols[i] || ""));
          return obj;
        });

        const mapped = data
          .filter((p) => p.id && p.nombre)
          .map((p) => ({
            id: p.id,
            name: p.nombre,
            price: parseInt(p.precio, 10) || 0,
            short: p.descripcion,
            images: [p.imagen1, p.imagen2, p.imagen3].filter(Boolean),
          }));

        setProducts(mapped);
      } catch (err) {
        console.error("Error cargando productos:", err);
      }
    }
    fetchProducts();
  }, []);

  const total = useMemo(
    () =>
      Object.values(cart).reduce((sum, item) => sum + item.product.price * item.qty, 0),
    [cart]
  );

  const addToCart = (p) => {
    setCart((c) => {
      const current = c[p.id]?.qty || 0;
      return { ...c, [p.id]: { product: p, qty: current + 1 } };
    });
  };

  const buildWhatsAppLink = () => {
    const items = Object.values(cart);
    if (items.length === 0) return "#";

    const lines = [
      "Hola, quiero hacer este pedido:",
      ...items.map(
        (it, idx) => `${idx + 1}. ${it.product.name} x${it.qty} — ${formatCOP(it.product.price * it.qty)}`
      ),
      `Total: ${formatCOP(total)}`,
    ];

    const text = encodeURIComponent(lines.join("\n"));
    return `https://wa.me/${WHATSAPP_NUMBER}?text=${text}`;
  };

  return (
    <div style={{ fontFamily: "sans-serif", padding: 20 }}>
      <h1>Tienda de Accesorios</h1>
      <p>Catálogo cargado desde Google Sheets.</p>

      {products.length === 0 ? (
        <p>Cargando productos...</p>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: 20 }}>
          {products.map((p) => (
            <div key={p.id} style={{ border: "1px solid #ddd", borderRadius: 12, padding: 12 }}>
              <h3>{p.name}</h3>
              {p.images[0] && <img src={p.images[0]} alt={p.name} style={{ width: "100%", borderRadius: 8 }} />}
              <p>{p.short}</p>
              <p><strong>{formatCOP(p.price)}</strong></p>
              <button onClick={() => addToCart(p)}>Agregar al carrito</button>
            </div>
          ))}
        </div>
      )}

      <hr style={{ margin: "20px 0" }} />

      <h2>Carrito</h2>
      {Object.values(cart).length === 0 ? (
        <p>Aún no tienes productos.</p>
      ) : (
        <div>
          <ul>
            {Object.values(cart).map((item) => (
              <li key={item.product.id}>
                {item.product.name} x{item.qty} — {formatCOP(item.product.price * item.qty)}
              </li>
            ))}
          </ul>
          <p><strong>Total: {formatCOP(total)}</strong></p>
          <a href={buildWhatsAppLink()} target="_blank" rel="noopener noreferrer">
            <button>Enviar pedido por WhatsApp</button>
          </a>
        </div>
      )}
    </div>
  );
}
